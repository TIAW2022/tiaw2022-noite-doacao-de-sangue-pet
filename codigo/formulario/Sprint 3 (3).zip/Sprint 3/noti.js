document.querySelector(".kapsayici").onclick=function(){
    if(document.getElementById("check").checked){
      document.querySelector(".symbol").style.transform="rotate(-90deg)";
    }
    else{
      document.querySelector(".symbol").style.transform="rotate(90deg)";
    }
  }

  let imgFoto = document.querySelector('#foto')
  let nome = document.querySelector('#nome')
  let email = document.querySelector('#email')
  let telefone = document.querySelector('#telefone')
  let hospital = document.querySelector('#hospital')

  let sectionConteudos = document.querySelector('.conteudos')

  const utl = 'cards.json'

  function pegarDados(i){
    fetch(url)
    .then( response => response.json() )
    .then( dados => {
      if(dados.erro){
        console.log("Erro ao acessar o JSON")
        return
      }

      let qtdFormulario = (dados.formulario.length)
      console.log("Quant. de Formulario" + qtdFormulario)

      atribuirDados2(dados, i)
    })
  }

  function atribuirDados(dados, i){
    imgsFoto.setAttribute('src', "imges/pride"+dados.formulario[i].foto)
    nome.textContent = dados.formulario[i].nome
    email.textContent = dados.formulario[i].email
    telefone.textContent = dados.formulario[i].telefone
    hospital.textContent = dados.formulario[i].hospital
  }

  //selecionar todos os cards por class

  let imgsFoto = document.getElementsByClassName('foto')
  let nomesFormulario = document.getElementsByClassName('nome')
  let emailFormulario = document.getElementsByClassName('email')
  let telefoneFormulario = document.getElementsByClassName('telefone')
  let hospitalFormulario = document.getElementsByClassName('hospital')
 

  function atribuirDados2(dados, i){
    imgsFoto[i].setAttribute('src', "imges/pride"+dados.formulario[i].foto)
    nomesFormulario[1].textContent = dados.formulario[i].nome
    emailFormulario[1].textContent = dados.formulario[i].email
    telefoneFormulario[1].textContent = dados.formulario[i].telefone
    hospitalFormulario[1].textContent = dados.formulario[i].hospital
  }


  //usamos as funcoes createElement e appendChlid
  // para criar article (elemento html que vai acomodar cada carta)
  // criamos tamvem img, h2 e h3. Depois colocamos eles dentro do article
  function desenharCarta(id){
    //card
    let carta = document.createElement("article")
    carta.setAttribute('class', 'card')
    sectionConteudos.appendChild(carta)

    //imagem dentro do card

    let imagem = document.createElement("img")
    carta.appendChild(imagem)
    imagem.setAttribute('class', 'foto')
    imagem.setAttribute('src', 'images/alfredo.jpg')

    // nome do pet

    let nomeFormulario = document.createElement("h2")
    nomeFormulario.setAttribute('class', 'nome')
    carta.appendChild(nomeFormulario)
    nomeFormulario.textContent = "Nome"

    // email
    let emailFormulario = document.createElement("h3")
    emailFormulario.setAttribute('class', 'email')
    carta.appendChild(emailFormulario)
    emailFormulario.textContent = "Email"

     // telefone
    let telefoneFormulario = document.createElement("h3")
    telefoneFormulario.setAttribute('class', 'telefone')
    carta.appendChild(telefoneFormulario)
    telefoneFormulario.textContent = "Telefone"

    // hopital
    let hospitalFormulario = document.createElement("h3")
    hospitalFormulario.setAttribute('class', 'hospital')
    carta.appendChild(hospitalFormulario)
    hospitalFormulario.textContent = "Hospital"

    pegarDados(id)

  }

  //1a carta pegamos os dados. Ela ja esta desenhada na tela 
  pegarDados(0)

  //2a carta em diante desenhamos em tela usando as funçoes 
  // desenharCarta(0)
  desenharCarta(1)
  desenharCarta(2)
  desenharCarta(3)
  desenharCarta(4)

  desenharCarta(5) 
  desenharCarta(6)
  desenharCarta(7)
  desenharCarta(8)
  desenharCarta(9)

 

